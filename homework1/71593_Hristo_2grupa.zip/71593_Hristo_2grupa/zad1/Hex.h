#ifndef HEX_H
#define HEX_H


class Hex
{
private:
    char number[101];
    int numberDecimal[200];
    int counter,
             counterDec;
    bool validation (char*, int);
    void convertDecimal ();
public:
        void convertHex ();

    Hex();
    Hex(char* , int);
    Hex(Hex&);
    Hex& operator= (const Hex&);

    Hex& operator+ (const Hex&);
    Hex& operator- (const Hex&);
    Hex& operator* (const Hex&);
    Hex& operator/ (const Hex&);

    bool operator< (const Hex&);
    bool operator> (const Hex&);
    bool operator== (const Hex&);

    void print() const;

    friend void sumDec (int*, int&, int*, int);
    friend void multDec (int*, int&, const int*, const int);
    friend void minDec (int*, int&, const int*, const int);
    friend void divDec (int*, int&, const int*, const int, bool);

};

#endif // HEX_H
