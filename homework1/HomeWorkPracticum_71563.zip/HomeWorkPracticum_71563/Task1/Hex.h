#ifndef Hex_h
#define Hex_h

class Hex{
private:
	char* hexNumber;
	int size;
	int capacity;
public:
	Hex();
	Hex(char*);
	~Hex();
	Hex(const Hex&);
	Hex& operator=(const Hex&);
	Hex& operator+(const Hex&);
	Hex& operator-(const Hex&);
	Hex& operator*(const Hex&);
	Hex& operator/(const Hex&);
	bool operator>(const Hex&);
	bool operator<(const Hex&);
	bool operator==(const Hex&);
	bool operator!=(const Hex&);
	int toDecimal(const Hex&);
	void print()const;
	

};
#endif