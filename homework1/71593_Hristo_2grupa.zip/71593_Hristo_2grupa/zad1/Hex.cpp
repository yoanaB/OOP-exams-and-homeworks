#include "Hex.h"

Hex:: Hex()
{
    number[0] = '\0';
    counter = 0;
}
Hex:: Hex(char number[101],int counter):
    counter(counter)
{
    strncpy(this -> number, number, counter);
    if(!validation(this -> number, counter))
    {
        cout << "error" << endl;
        this -> number[0] = '\0';
        this -> counter = 0;
    }
    else
        convertDecimal();
}
bool Hex:: validation (char number[101], int counter)
{
    if(counter > 100)
        return 0;
    if(number[counter - 1] == '0')
        return 0;
    for(int i = 0; i < counter; i++)
    {
        if(number[i] >= 'a' && number[i] <= 'f')
            number[i] = number[i] - ('a' - 'A');
        if(number[i] < '0' || (number[i] > '9' && number[i] < 'A') || number[i] > 'F')
            return 0;
    }

    return 1;
}
Hex:: Hex(Hex& other)
{
    counter = other.counter;
    strncpy(number,other.number,counter);
    counter = other.counter;
    counterDec = other.counterDec;
    for(int i = 0; i < counterDec; i++)
        numberDecimal[i] = other.numberDecimal[i];
}
Hex& Hex:: operator= (const Hex& other)
{
    if(this == &other)
        return *this;
    counter = other.counter;
    strncpy(number,other.number,counter);
    counter = other.counter;
    counterDec = other.counterDec;
    for(int i = 0; i < counterDec; i++)
        numberDecimal[i] = other.numberDecimal[i];
        return *this;
}

void sumDec (int left[200],int& countLeft, const int right[200], int countRight)
{
    for(int i = 0; i < countRight; i++)
    {
        if(i == countLeft)
        {
            left[i] = 0;
            countLeft++;
        }
        left[i] += right[i];
        if(left[i] > 9)
        {
            if(i == countLeft - 1)
                left[countLeft++] = 0;
            left[i + 1]++;
            left[i] -= 10;
        }
    }
}


void minHelper (int* arr)
{
    arr[0] = 9;
    if(arr[1] == 0)
        minHelper(&(arr[1]));
    else
        arr[1]--;
}
void minDec (int left[200],int& countLeft, const int right[200], int countRight)
{
    for(int i = 0; i < countRight; i++)
    {
        left[i] -= right[i];
        if(left[i] < 0)
        {
            left[i] += 10;
            if(left[i + 1] == 0)
            {
                minHelper(&(left[i+1]));
            }
            else
                left[i + 1]--;

        }
    }
    for(int i = countLeft - 1; left[i] == 0 && i > 0; i--)
        countLeft--;
}

void multDec (int left[200], int& countLeft, const int right[200], int countRight)
{
    int mult[200];
    int multCounter = 1;
    for(int i = 0; i < countLeft; i++, multCounter++)
    {
        if(i > 0 && mult[i - 1] > 9)
        {
            mult[i] = mult[i - 1] / 10;
            mult[i - 1] %= 10;
        }
        else
            mult[i] = 0;
        mult[i] += left[i] * right[0];
    }
    multCounter--;
    if(mult[multCounter - 1] > 9)
    {
        mult[multCounter] = mult[multCounter - 1] / 10;
        mult[multCounter - 1] %= 10;
        multCounter++;
    }
    for(int j = 1; j < countRight; j++)
    {
        int tmp[200];
        int tmpCounter = j;
        for(int i = 0; i < j; i++)
            tmp[i] = 0;
        for(int i = 0; i < countLeft; i++, tmpCounter++)
        {
            if(tmp[tmpCounter - 1] > 9)
            {
                tmp[tmpCounter] = tmp[tmpCounter - 1] / 10;
                tmp[tmpCounter - 1] %= 10;
            }
            else
                tmp[tmpCounter] = 0;
            tmp[tmpCounter] += left[i] * right[j];
        }
        if(tmp[tmpCounter - 1] > 9)
        {
            tmp[tmpCounter] = tmp[tmpCounter - 1] / 10;
            tmp[tmpCounter - 1] %= 10;
            tmpCounter++;
        }
        sumDec(mult,multCounter,tmp,tmpCounter);
    }
    for(int i = 0; i < multCounter; i++)
        left[i] = mult[i];
    countLeft = multCounter;
    if(left[countLeft - 1] == 0)
        countLeft--;
}

bool divHelper (int left[200], int countLeft, const int right[200], int countRight)
{
    if(countLeft > countRight)
        return 1;
    if(countLeft < countRight)
        return 0;
    for(int i = countLeft - 1; i >= 0; i--)
    {
        if(left[i] > right[i])
            return 1;
        if(left[i] < right[i])
            return 0;
    }
    return 1;

}

void divHelper2 (int* arr, int start)
{
    if(arr[start] == 9)
    {
        arr[start] = 0;
        arr[++start]++;
        divHelper2 (arr, start);
    }
}

void divDec (int left[200], int& countLeft, const int right[200], int countRight, bool flag)
{
    int tmp[200];
    int tmpCounter = 1;
    tmp[0] = 0;
    while(divHelper(left,countLeft,right,countRight))
    {
        minDec(left, countLeft, right, countRight);
        tmp[0]++;
        if(tmp[0] == 9)
        {
            tmp[tmpCounter] = 0;
            divHelper2(tmp,0);
            if(tmp[tmpCounter] == 1)
                tmpCounter++;
            tmp[0] = -1;

        }
    }
    if(!flag)
    {
        if(countLeft == 2)
            countLeft = left[0] + 10*left[1];
        else if(countLeft == 1)
            countLeft = left[0];
            cout << countLeft << endl;
        left[tmpCounter] = -1;
    }
    else
        countLeft = tmpCounter;
    for(int i = 0; i < tmpCounter; i++)
        left[i] = tmp[i];
}

void Hex:: convertDecimal ()
{
    int numberDecimal2[200],syst[200];
    syst[0] = 6;
    syst[1] = 1;
    counterDec = 0;
    for(int i = 0; i < counter; i++)
    {
        if(number[i] >= '0' && number[i] <= '9')
            numberDecimal2[i] = number[i] - '0';
        else
            numberDecimal2[i] = 10 +(number[i] - 'A');
    }
    if(numberDecimal2[counter - 1] <= 9)
    {
        numberDecimal[0] = numberDecimal2[counter - 1];
        counterDec = 1;
    }
    else
    {
        numberDecimal[0] = numberDecimal2[counter - 1] % 10;
        numberDecimal[1] = numberDecimal2[counter - 1] / 10;
        counterDec = 2;
    }

    for(int i = counter- 2; i >= 0; i--)
    {
        multDec(numberDecimal,counterDec,syst,2);
        int tmp[200],tmpCount;
        if(numberDecimal2[i] > 9)
        {
            tmp[0] = numberDecimal2[i] % 10;
            tmp[1] = numberDecimal2[i] / 10;
            tmpCount = 2;
        }
        else
        {
            tmp[0] = numberDecimal2[i];
            tmpCount = 1;
        }
        sumDec(numberDecimal,counterDec,tmp,tmpCount);
    }
    while (numberDecimal[counterDec - 1] == 0)
        counterDec--;
}
void Hex:: convertHex ()
{
    int decimal[200],numberDecimal2[200];
    int counterDec2 = counterDec;
    decimal[0] = 6;
    decimal[1] = 1;
    for(int i = 0; i < counterDec; i++)
        numberDecimal2[i] = numberDecimal[i];
    counter = 0;


    while((counterDec2 == 2 && numberDecimal2[1] >= 0 && numberDecimal2[1] < 6 && numberDecimal2[0] == 1) || counterDec2 == 1)
    {
        divDec(numberDecimal2,counterDec2,decimal,2,0);
        if(counterDec2 > 9)
            number[counter++] = 'A' + counterDec2 - 10;
        else
            number[counter++] = counterDec2 + '0';
        for(counterDec2 = 0; counterDec2 != -1; counterDec2++){}
    }
}

Hex& Hex:: operator+ (const Hex& other)
{
    sumDec(numberDecimal,counterDec,other.numberDecimal,other.counterDec);
    convertHex();
    return *this;
}

Hex& Hex:: operator- (const Hex& other)
{
    if(*this > other)
        minDec(numberDecimal,counterDec,other.numberDecimal,other.counterDec);
    else
    {
        number[0] = '0';
        numberDecimal[0] = 0;
        counter = 1;
        counterDec = 1;
    }
    convertHex();
    return *this;
}
Hex& Hex:: operator* (const Hex& other)
{
    multDec(numberDecimal,counterDec,other.numberDecimal,other.counterDec);
    convertHex();
    return *this;
}
Hex& Hex:: operator/ (const Hex& other)
{
    if(divHelper(numberDecimal,counterDec,other.numberDecimal, other.counterDec))
        divDec(numberDecimal,counterDec,other.numberDecimal,other.counterDec,1);
    else
    {
        number[0] = '0';
        numberDecimal[0] = 0;
        counter = 1;
        counterDec = 1;
    }
    convertHex();
    return *this;
}

bool Hex:: operator< (const Hex& other)
{
    if(counterDec > other.counterDec)
        return 0;
    for(int i = counterDec - 1, j = other.counterDec - 1; i >= 0; i--, j--)
        if(numberDecimal[i] > other.numberDecimal[j])
            return 0;
    if(numberDecimal[0] == other.numberDecimal[0])
        return 0;
    return 1;
}

bool Hex:: operator> (const Hex& other)
{
    if(counterDec < other.counterDec)
        return 0;
    if(counterDec > other.counterDec)
        return 0;
    for(int i = counterDec - 1, j = other.counterDec - 1; j >= 0; i--, j--)
    {
        if(numberDecimal[i] < other.numberDecimal[j])
            return 0;
        if(numberDecimal[i] > other.numberDecimal[j])
            return 1;
    }
    return 0;
}

bool Hex:: operator== (const Hex& other)
{
    if(counterDec != other.counterDec)
        return 0;
    for(int i = counterDec - 1; i >= 0; i--)
        if(numberDecimal[i] != other.numberDecimal[i])
            return 0;
    return 1;
}

void Hex:: print() const
{
    cout << "Hex: ";
    for (int i = 0; i < counter; i++)
        cout << number[i];
    cout << endl << "Dec: ";
    for(int i = 0; i < counterDec; i++)
         cout << numberDecimal[i];
         cout << endl;
}
