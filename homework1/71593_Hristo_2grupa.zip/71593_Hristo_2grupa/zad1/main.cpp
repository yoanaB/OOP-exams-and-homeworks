#include <iostream>
#include<cstring>
using namespace std;

#include "Hex.cpp"

int main ()
{

}
