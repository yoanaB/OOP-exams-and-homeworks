#include<iostream>
#include <cmath>
#include <string.h>
using namespace std;
#include "Hex.h"

Hex::Hex(const Hex& other){
	size = other.size;
	capacity = other.capacity;
	size_t length = strlen(other.hexNumber) + 1;
	this->hexNumber = new char[length];
	for (int i = 0; i < size; i++)
	{
		hexNumber[i] = other.hexNumber[i];
	}
}
Hex::Hex(){
	size = 0;
	capacity = 1;
	hexNumber = new char[capacity];
	hexNumber[0] = '\0';
}
Hex::Hex(char* _hexNumber)
{
	this->size = strlen(_hexNumber);
	this->hexNumber = new char[size + 1];
	int j = size - 1;
	for (int i = 0; i < size + 1; i++)
	{
		this->hexNumber[i] = hexNumber[j];
		j--;
	}
}
Hex::~Hex(){
	delete[] hexNumber;
}
Hex& Hex::operator=(const Hex& other){
	if (this != &other){
		delete[] hexNumber;
		size = other.size;
		capacity = other.capacity;
		hexNumber = new char[capacity];
		for (int i = 0; i < size; i++){
			hexNumber[i] = other.hexNumber[i];
		}
	}
	return *this;
}
Hex& Hex::operator+(const Hex& other)
{
	int value = toDecimal(*this) + toDecimal(other);
	char*otherHex = _itoa(value, hexNumber, 16);
	this->size = strlen(otherHex);
	size_t length = strlen(otherHex) + 1;
	this->hexNumber = new char[length];
	int j = size - 1;
	for (int i = 0; i < size; i++)
	{
		hexNumber[i] = otherHex[j];
		j--;
	}
	hexNumber[size] = '\0';
	delete[] otherHex;
	return *this;
}
Hex& Hex::operator-(const Hex& other)
{
	int value = toDecimal(*this) - toDecimal(other);
	char*otherHex = _itoa(value, hexNumber, 16);
	this->size = strlen(otherHex);
	size_t length = strlen(otherHex) + 1;
	this->hexNumber = new char[length];
	int j = size - 1;
	for (int i = 0; i < size; i++)
	{
		hexNumber[i] = otherHex[j];
		j--;
	}
	hexNumber[size] = '\0';
	delete[] otherHex;
	return *this;
}
Hex& Hex::operator*(const Hex& other)
{
	int value = (toDecimal(*this)) * (toDecimal(other));
	char* otherHex = _itoa(value, hexNumber, 16);
	this->size = strlen(otherHex);
	size_t length = strlen(otherHex) + 1;
	this->hexNumber = new char[length];
	int j = size - 1;
	for (int i = 0; i < size;i++)
	{
		hexNumber[i] = otherHex[j];
		j--;
	}
	hexNumber[size] = '\0';
	delete[] otherHex;
	return *this;
}
Hex& Hex::operator/(const Hex& other)
{
	int value = toDecimal(*this) / toDecimal(other);
	char* otherHex = _itoa(value, hexNumber, 16);
	this->size = strlen(otherHex);
	size_t length = strlen(otherHex) + 1;
	this->hexNumber = new char[length];
	int j = size - 1;
	for (int i = 0; i < size;i++)
	{
		hexNumber[i] = otherHex[j];
	}
	hexNumber[size] = '\0';
	delete[] otherHex;
	return *this;
}

bool Hex::operator>(const Hex& other)
{
	return toDecimal(*this) > toDecimal(other);
}
bool Hex::operator==(const Hex& other)
{
	return toDecimal(*this) == toDecimal(other);
}
bool Hex::operator<(const Hex& other)
{
	return *this < other;
}
void Hex::print()const{
	cout << "Hex is: " << this->hexNumber << endl;
}
bool Hex::operator!=(const Hex& other)
{
	return *this != other;
}
int Hex::toDecimal(const Hex& other)
{
	int otherHex = 0;
	for (int i = 0; i < other.size; i++) {
		if (other.hexNumber[i] >= 48 && other.hexNumber[i] <= 57)
		{
			otherHex += (other.hexNumber[i] - 48)*pow(16, other.size - i - 1);
		}else if (other.hexNumber[i] >= 65 && other.hexNumber[i] <= 70) {
			otherHex += (other.hexNumber[i] - 55)*pow(16, other.size - i - 1);
		}else if (other.hexNumber[i] >= 97 && other.hexNumber[i] <= 102) {
			otherHex += (other.hexNumber[i] - 87)*pow(16, other.size - i - 1);
		}
	}
	return otherHex;
}
int main(){
	Hex x("56");
	Hex y("20");
	/**/
	return 0;
}