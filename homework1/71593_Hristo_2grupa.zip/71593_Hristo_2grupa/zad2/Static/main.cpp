#include <iostream>
#include <cstring>
using namespace std;


#include "ListPerson.cpp"
Zodiac ListPerson:: zodii[12];
int main ()
{
    ListPerson::fillZodii();
}
