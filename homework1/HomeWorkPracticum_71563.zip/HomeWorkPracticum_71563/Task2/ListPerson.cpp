#include <iostream>
using namespace std;
#include "ListPerson.h"	

ListPerson::ListPerson(){
	size = 0;
	capacity = 1;
}
ListPerson::ListPerson(char* _lastName = "", int _month = 1, int _year = 1900){
	for (int i = 0; i < size; i++){
		peopleCards[i].lastName = _lastName;
		peopleCards[i].month = _month;
		peopleCards[i].year = _year;
	}
}
ListPerson::~ListPerson(){
	delete[] peopleCards;
}
ListPerson::ListPerson(const ListPerson& other){
	size = other.size;
	capacity = other.capacity;
	peopleCards = new card[capacity];
	for (int i = 0; i < size; i++)
	{
		peopleCards[i] = other.peopleCards[i];
	}
}
ListPerson& ListPerson::operator=(const ListPerson& other){
	if (this != &other){
		delete[] peopleCards;
		size = other.size;
		capacity = other.capacity;
		peopleCards = new card[capacity];
		for (int i = 0; i < size; i++)
		{
			peopleCards[i] = other.peopleCards[i];
		}
	}
	return *this;
}
card ListPerson::getCard(char* _lastName)const{
	for (int i = 0; i < size; i++)
	{
		if (peopleCards[i].lastName == _lastName){
			return peopleCards[i];
		}
	}
}
unsigned ListPerson::getNumberOfCards()const{
	return size;
}
void ListPerson::addCard(const card& _card){
	if (size == capacity){
		card* oldCards = peopleCards;
		peopleCards = new card[2 * capacity];
		for (int i = 0; i < size; i++)
		{
			peopleCards[i] = oldCards[i];
		}
		delete[] oldCards;
		capacity *= 2;
	}
	peopleCards[size++] = _card;
}
void ListPerson::removeCard(char* _lastName){
	for (int i = 0; i < size; i++)
	{
		if (peopleCards[i].lastName == _lastName){
			for (int j = i + 1; j < size; j++)
			{
				peopleCards[j - 1] = peopleCards[j];
			}
			--size;
			return;
		}
	}
}
void ListPerson::print()const{
	for (int i = 0; i < size; i++)
	{
		cout << "Last name: " << peopleCards[i].lastName << " Month: " << peopleCards[i].month << " Year: " << peopleCards[i].year << endl;
	}
}
int main(){
	ListPerson a("Ivan", 1, 1995);
	a.print();
	return 0;
}