#ifndef Person_h
#define Person_h
struct card{
	char* lastName;
	int month;
	int year;
};
class ListPerson{
private:
	card* peopleCards;
	unsigned size;
	unsigned capacity;

public:
	ListPerson(char*, int, int);
	ListPerson();
	~ListPerson();
	ListPerson(const ListPerson&);
	ListPerson& operator=(const ListPerson&);
	void addCard(const card&);
	void removeCard(char*);
	card getCard(char*)const;
	unsigned getNumberOfCards()const;
	void print()const;
};

#endif